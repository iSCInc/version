<?php
/** Crimean Turkish (Qırımtatarca)
 *
 * @ingroup Language
 * @file
 *
 * @author Alessandro
 */

$fallback = 'crh-latn';

$linkTrail = '/^([a-zâçğıñöşüа-яёʺʹ“»]+)(.*)$/sDu';
