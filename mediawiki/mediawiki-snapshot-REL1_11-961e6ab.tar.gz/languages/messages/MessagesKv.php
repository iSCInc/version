<?php
/** Komi (Коми)
  *
  * @addtogroup Language
  */

$fallback = 'ru';

