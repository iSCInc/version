<?php

/** Aramaic ( ܕܥܒܪܸܝܛ )
  *
  * @addtogroup Language
  */

$rtl = true;
$defaultUserOptionOverrides = array(
	# Swap sidebar to right side by default
	'quickbar' => 2,
);


