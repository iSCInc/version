<?php

$rtl = true;


