<?php
/** Tahitian (Reo Mā`ohi)
  *
  * @addtogroup Language
  */

$fallback = 'fr';

