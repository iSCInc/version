<?php
/** Sindhi language file ( सिनधि )
  *
  * @addtogroup Language
  */

#FIXME: inherit almost everything for now

$rtl = true;


