<?php
/**
  * @addtogroup Language
  */

# Inherit everything for now
$fallback = 'sr-ec';


