<?php
/** Neapolitan (Nnapulitano)
  *
  * @addtogroup Language
  */

$fallback = 'it';


