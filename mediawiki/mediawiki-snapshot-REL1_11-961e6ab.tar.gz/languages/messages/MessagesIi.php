<?php
/** Yi (ꆇꉙ)
  *
  * @addtogroup Language
  */

$fallback = 'zh-cn';

