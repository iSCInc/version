<?php
/** Avar (Авар)
  *
  * @addtogroup Language
  */

$fallback = 'ru';
