<?php
/** Belarusian in Taraškievica orthography (Беларуская тарашкевіца)
  *
  * @addtogroup Language
  * @comment dummy language file. Falls back to 'be-tarask'. Backward compat.
  */

$fallback = 'be-tarask';
