<?php
/** Bavarian (Boarisch)
 *
 * @ingroup Language
 * @file
 *
 * @author Malafaya
 * @author Man77
 * @author Metalhead64
 */

$fallback = 'de';

$messages = array(
# User preference toggles
'tog-underline'          => 'Links untastreicha:',
'tog-highlightbroken'    => 'Links auf leere Seiten hervorhem',
'tog-justify'            => 'Text ois Blocksatz',
'tog-hideminor'          => 'Kloane Änderunga ausblendn',
'tog-extendwatchlist'    => 'Erweiterte Beobachtungslistn',
'tog-showtoolbar'        => 'Bearbatn-Werkzeugleiste oozoang',
'tog-watchcreations'     => 'Vu mia söiwa nei eigstöide Seitn automatisch beobåchtn',
'tog-watchdefault'       => 'Vu mia söiwa beåabeitete und vu mia nei eigstöide Seitn automatisch beobåchtn',
'tog-watchmoves'         => 'Vu mia söiwa vaschomne Seitn automatisch beobåchtn',
'tog-watchdeletion'      => 'Vu mia söiwa glöschte Seitn automatisch beobåchtn',
'tog-minordefault'       => 'De eigenen Ändarungen standardmäßig åis geringfügig markian',
'tog-fancysig'           => 'Signatua ohne Valinkung zu da Benutzaseitn',
'tog-forceeditsummary'   => 'Warnen, wenn beim Speichern de Zusammenfassung feit',
'tog-watchlisthideown'   => 'Eigne Bearbatunga in dar Beobachtungslistn ausblendn',
'tog-watchlisthidebots'  => 'Bearbatunga durch Bots in da Beobachtungslistn ausblendn',
'tog-watchlisthideminor' => 'Kloane Bearbatunga in da Beobachtungslistn ausblendn',

'underline-always' => 'imma',
'underline-never'  => 'nia',

# Dates
'sat'         => 'Sa',
'january'     => 'Jänna',
'april'       => 'Aprüi',
'may_long'    => 'Mai',
'june'        => 'Juni',
'july'        => 'Juli',
'august'      => 'August',
'september'   => 'Septemba',
'october'     => 'Oktowa',
'november'    => 'Novemba',
'december'    => 'Dezemba',
'january-gen' => 'Jänner',
'jan'         => 'Jän.',

# Bits of text used by many pages
'pagecategories'        => '{{PLURAL:$1|Kategorie|Kategorien}}',
'category_header'       => 'Seitn in da Kategorie „$1“',
'subcategories'         => 'Untakategorien',
'category-media-header' => 'Medien in da Kategorie „$1“',
'category-empty'        => "''De Kategorie enthåit momentan kane Seitn und kane Medien ned.''",

'mainpagetext'      => "<big>'''MediaWiki is eafoigreich installiad woan.'''</big>",
'mainpagedocfooter' => 'A Huif zua Benutzung und Konfiguration vo da Wiki-Software findst im [http://meta.wikimedia.org/wiki/Help:Contents Benutzerhandbuch].
* [http://lists.wikimedia.org/mailman/listinfo/mediawiki-announce Mailingliste neuer MediaWiki-Versionen]',

'about'          => 'Üba',
'article'        => 'Artikl',
'newwindow'      => '(wiad in am neichn Fensta aufgmåcht)',
'cancel'         => 'Åbbrecha',
'qbmyoptions'    => 'Meine Seitn',
'qbspecialpages' => 'Spezialseitn',
'moredotdotdot'  => 'Mehra …',
'mypage'         => 'Eigne Seitn',
'mytalk'         => 'Eigne Diskussion',
'anontalk'       => 'Diskussionsseitn vo dera IP',

'returnto'          => 'Zruck zur Seitn $1.',
'tagline'           => 'Aus {{SITENAME}}',
'help'              => 'Fragen?',
'search'            => 'Suach',
'searchbutton'      => 'Suach',
'searcharticle'     => 'Artikl',
'history'           => 'Versionen',
'updatedmarker'     => '(gändat)',
'printableversion'  => 'Version zum Ausdruckn',
'permalink'         => 'Bschtändige URL',
'edit'              => 'werkln',
'editthispage'      => 'Seitn beårbeitn',
'delete'            => 'löschn',
'deletethispage'    => 'De Seitn löschn',
'undelete_short'    => '{{PLURAL:$1|1 Version|$1 Versionen}} wiedaheastöin',
'protect'           => 'Schützn',
'protect_change'    => 'ändan',
'protectthispage'   => 'Seitn schützn',
'unprotect'         => 'freigem',
'unprotectthispage' => 'Schutz aufhem',
'newpage'           => 'Neiche Seitn',
'talkpagelinktext'  => 'bschprecha',
'articlepage'       => 'Artikl',
'talk'              => 'bschprecha',
'toolbox'           => 'Weakzeigkistn',
'userpage'          => 'Benutzerseitn',
'mediawikipage'     => 'Inhaltsseitn ozoang',
'categorypage'      => 'Kategorieseitn ozoang',
'otherlanguages'    => 'Åndane Språchn',
'lastmodifiedat'    => 'De Seitn is zletzt am $1 um $2 gändert worn.', # $1 date, $2 time
'jumpto'            => 'Wechseln zua:',
'jumptosearch'      => 'Suach',

# All link text and link target definitions of links into project namespace that get used by other message strings, with the exception of user group pages (see grouppage) and the disambiguation template definition (see disambiguations).
'aboutsite'    => 'Üba {{SITENAME}}',
'aboutpage'    => 'Project:Üba_{{SITENAME}}',
'disclaimers'  => 'Impressum',
'edithelp'     => 'Bearbeitungshuifn',
'edithelppage' => 'Help:Bearbeitungshuifn',
'mainpage'     => 'Hauptsaitn',
'privacy'      => 'Datnschutz',

'badaccess' => 'Koane ausreichenden Rechte',

'ok'                      => 'haut hi',
'retrievedfrom'           => 'Vu „$1“',
'youhavenewmessages'      => 'Sie ham $1 ($2).',
'newmessageslink'         => 'neie Nachrichten',
'newmessagesdifflink'     => 'neie Nachrichtn',
'youhavenewmessagesmulti' => 'Sie ham neie Nachrichten: $1',
'editsection'             => 'werkln',
'editold'                 => 'werkln',
'toc'                     => 'Inhoitsvazeichnis',
'showtoc'                 => 'Ozoang',
'thisisdeleted'           => '$1 ooschaun oda wieda herstelln?',
'viewdeleted'             => '$1 oozoang?',
'red-link-title'          => "$1 (de Seitn gibt's ned)",

# Short words for each namespace, by default used in the namespace tab in monobook
'nstab-user'    => 'Benutzerseitn',
'nstab-special' => 'Spezialseitn',
'nstab-project' => 'Projektseitn',
'nstab-image'   => 'Datei',

# General errors
'error'               => 'Fehla',
'databaseerror'       => 'Fehla in da Datenbank',
'noconnect'           => 'Konn koa Verbindung zur Datenbank auf $1 herstelln',
'filedeleteerror'     => 'De Datei „$1“ håt net glöscht wern kinna.',
'filenotfound'        => 'De Datei „$1“ is net gfundn worn.',
'badarticleerror'     => 'De Aktion kann net auf de Seitn ogwendt wern.',
'badtitletext'        => 'Da Titl vo dera oogfordertn Seitn is net gültig, laar oda a ungültigar Sprachlink vo an andern Wiki.',
'actionthrottledtext' => 'Diese Aktion kann in einem kurzen Zeitabstand nur begrenzt oft ausgeführt werden. Du hast diese Grenze soeben erreicht. Bitte versuche es in einigen Minuten erneut.',
'viewsourcetext'      => 'Sie kinnan aba an Quelltext vo dera Seitn ooschaun und kopiern:',
'editinginterface'    => "'''Obacht:''' De Seitn enthoit von da MediaWiki-Software benutzten Text. Änderungen wirken si auf de Benutzeroberfläche aus.",
'titleprotected'      => "A Seitn mit dem Nama kann net ogelegt wern. De Sperre is durch [[User:$1|$1]] mit da Begründung ''„$2“'' eigericht worn.",

# Login and logout pages
'logouttext'                 => 'Sie san iatzat abgmeldt.
Sie kinnan {{SITENAME}} iatzat anonym weitanutzn, oda si unta am selben oda am andern Benutzernamen wieder omeldn.',
'yourname'                   => 'Benutzernam:',
'yourpasswordagain'          => 'Passwort no amoi',
'yourdomainname'             => 'Eanane Domain:',
'login'                      => 'Oomeidn',
'userlogin'                  => 'Oomeidn',
'logout'                     => 'Obmeidn',
'userlogout'                 => 'Obmeidn',
'notloggedin'                => 'Net ogmeldt',
'nologin'                    => 'Du hast koa Benutzakonto? $1.',
'createaccount'              => 'Benutzerkonto oleng',
'gotaccount'                 => 'Du hast hast scho a Benutzerkonto? $1.',
'gotaccountlink'             => 'Omeidn',
'userexists'                 => "Der Benutzernam is schon vergem. Bittschee nehman S' an andern.",
'username'                   => 'Benutzernam:',
'yourrealname'               => 'Echter Nam:',
'yourlanguage'               => 'Sprache vo da Benutzeroberfläche:',
'loginerror'                 => 'Fehla bei da Oomeidung',
'nocookieslogin'             => "{{SITENAME}} nimmt Cookies zum Eiloggen vo de Benutzer her. Sie ham Cookies deaktiviert, bittschee aktiviern Sie de und versuchan's nomoi.",
'loginsuccesstitle'          => 'Omeidung is erfolgreich gwen',
'loginsuccess'               => 'Sie san  iatzat ois „$1“ bei {{SITENAME}} oogmeidt.',
'wrongpassword'              => "Des Passwort is falsch (oda fehlt). Bitte probier's no amoi.",
'wrongpasswordempty'         => 'Des eigemne Passwort is laar gwen. Bitte no amoi probiern.',
'mailmypassword'             => 'Neis Passwort zuasendn',
'passwordremindertitle'      => 'Neis Passwort fia a {{SITENAME}}-Benutzerkonto',
'acct_creation_throttle_hit' => 'Du hosst scho $1 {{PLURAL:$1|Benutzakonto|Benutzakonten}} und konnst iatzat koane mehr oleng.',
'accountcreated'             => 'Benutzerkonto is erstellt worn',
'accountcreatedtext'         => "'s Benutzerkonto $1 is eigricht worn.",

# Edit page toolbar
'sig_tip' => 'Dei Signatur mit Zeitstempe',

# Edit pages
'minoredit'                => 'Nur Kloanigkeitn san verändert worn',
'watchthis'                => 'De Seitn beobachtn',
'savearticle'              => 'Seitn speichern',
'showpreview'              => 'Vorschau zoang',
'showdiff'                 => 'Ändarungen zoang',
'missingsummary'           => "'''Hinweis:''' Sie ham koa Zsammafassung oogem. Wenn S' wieda auf „Speichern“ klicken, werd Eana Änderung ohne Zsammafassung übanumma.",
'missingcommenttext'       => "Bitte gebn S' a Zsammafassung ei.",
'blockedtitle'             => 'Benutzer is gesperrt',
'whitelistedittitle'       => 'Zum Bearbatn miaßn Sie si oomeidn',
'whitelistedittext'        => 'Sie miaßn si $1, um Seiten bearbatn zum kinna.',
'whitelistreadtitle'       => 'Zum Lesn is erforderlich, ogmeldt zum sei',
'whitelistreadtext'        => 'Sie miaßn si [[Special:UserLogin|da oomeidn]], um de Seitn lesen zum kinna.',
'whitelistacctitle'        => 'Sie san net berechtigt, a Benutzerkonto ozumlegn.',
'confirmedittitle'         => 'Zum Bearbatn is a E-Mail-Bestätigung erforderlich.',
'loginreqtitle'            => 'Es braucht a Oomeidung',
'loginreqlink'             => 'oomeidn',
'loginreqpagetext'         => 'Sie miaßn si $1, um Seitn lesen zum kinna.',
'accmailtitle'             => 'Passwort is vaschickt worn',
'newarticle'               => '(Nei)',
'newarticletext'           => 'Da an Text vo da neien Seitn eintragn. Bitte nur in ganze Sätze schreim und koane urheberrechtsgeschützten Texte vo andere kopiern.',
'anontalkpagetext'         => "---- ''De Seitn werd dazu hergnumma, am net ogmeldten Benutzer Nachrichtn zum hinterlassen.
Wennst mit de Kommentare auf dera Seitn nix ofanga kåst, is vermutlich da friarare Inhaber vo dera IP-Adressn gmoant und du kånstas ignoriern.
Wennst a anonymer Benutzer bist und dengst, daß irrelevante Kommentare an di grichtet worn san, [[Special:UserLogin|meld di bitte o]], um zukünftig Verwirrung zum vermeiden. ''",
'previewconflict'          => "De Vorschau gibt an Inhalt vom obern Textfeld wieda; so werd de Seite ausschaun, wenn S' iatzat speichern.",
'session_fail_preview'     => '<strong>Dei Bearbeitung is net gspeichert worn, wei deine Sitzungsdaten valorn ganga san.
Bitte versuachs no amoi, indem du unta da foigendn Textvorschau nochmois auf „Seitn speichern“ klickst.
Sollt des Problem bestehn bleim, meld di ab und danach wieda oo.</strong>',
'editing'                  => 'Bearbatn vo $1',
'editconflict'             => 'Konflikt beim Bearbatn: $1',
'explainconflict'          => "Jemand anders hat de Seitn gändert, nachdem du oogfanga hast sie zum bearbatn.
Des obere Textfeld enthoit den aktuellen Stand.
Des untere Textfeld enthoit deine Änderungen.
Bitte füg deine Änderungen in des obere Textfeld ei.
'''Nur''' da Inhalt vom obern Textfeld werd gspeichert, wenn du auf „Seitn speichern“ klickst!",
'yourtext'                 => 'Eana Text',
'editingold'               => "<strong>ACHTUNG: Sie arbatn an a oidn Version vo dera Seit.
Wenn S' speichern, wern alle neiern Versionen übaschriem.</strong>",
'longpagewarning'          => "<strong>WARNUNG: De Seitn is $1 kB groaß; net jeda Browser konn Seitn bearbatn, di größer als 32 kB san.
Überlegen S' bitte, ob a Aufteilung vo da Seitn in kloanere Abschnitte möglich is.</strong>",
'semiprotectedpagewarning' => "'''Hoibsperrung:''' De Seitn is so gsperrt worn, daß nur registrierte Benutzer de ändern kinnan.",
'templatesused'            => 'De foigendn Vorlagn wern von dera Seitn vawendt:',
'templatesusedpreview'     => 'De foigendn Vorlagn wern von dera Seitnvorschau vawendt:',
'templatesusedsection'     => 'De foigendn Vorlagn wern von dem Abschnitt vawendt:',
'template-protected'       => '(schreibgschützt)',
'nocreatetitle'            => 'De Erstellung vo neie Seitn is eingeschränkt.',
'recreate-deleted-warn'    => "'''Obacht: Du ladst aa Datei hoach, de scho friara glöscht worn is.'''
Bittschee prüf gnau, ob as erneite Hoachladn de Richtlinien entspricht.
Zu deina Information folgt des Lösch-Logbuach mit da Begründung fia de vorherige Löschung:",

# Account creation failure
'cantcreateaccounttitle' => 'Benutzerkonto konn net erstellt wern.',

# History pages
'viewpagelogs' => 'Logbiacha fia de Seitn oozoang',
'histlegend'   => 'Zum Ozoagn vo Änderungen einfach de zwoa Versionen auswähln und auf de Schaltfläche „{{int:compareselectedversions}}“ klicken.<br />
* (Aktuell) = Untaschied zur aktuellen Version, (Vorherige) = Untaschied zur vorherigen Version
* Uhrzeit/Datum = Version zu dera Zeit, Benutzername/IP-Adresse vom Bearbeiter, K = Kloane Änderung',
'deletedrev'   => '[glöscht]',
'histlast'     => 'Neiste',
'historyempty' => '(laa)',

# Revision feed
'history-feed-title' => 'Versionshistorie',
'history-feed-empty' => "Die angeforderte Seitn gibt's net.
Vielleicht is sie gelöscht oda verschom worn.
[[Special:Search|Durchsuachan]] S' {{SITENAME}} für passende neie Seitn.",

# Revision deletion
'rev-delundel'            => 'zoang/vastecka',
'revdelete-nooldid-title' => 'Koa Version ogem',
'revdelete-text'          => "'''Der Inhalt oder andere Bestandteile gelöschter Versionen sind nicht mehr öffentlich einsehbar, erscheinen jedoch weiterhin als Einträge in der Versionsgeschichte.'''
{{SITENAME}}-Administratoren können den entfernten Inhalt oder andere entfernte Bestandteile weiterhin einsehen und wiederherstellen, es sei denn, es wurde festgelegt, dass die Zugangsbeschränkungen auch für Administratoren gelten.",

# Merge log
'revertmerge'      => 'Vareinigung zrucknehma',
'mergelogpagetext' => "Des is s'Logbuach vu de vareinigtn Versionsgschichtn.",

# Diffs
'history-title'           => 'Versionsgschicht vu „$1“',
'difference'              => '(Untaschied zwischn Versionen)',
'compareselectedversions' => 'Gwählte Versionen vergleicha',
'editundo'                => 'rückgängig',

# Search results
'searchresults'         => 'Suachergebnisse',
'searchresulttext'      => "Fia weidare Infos üwa's Suacha schau auf'd [[{{MediaWiki:Helppage}}|Hüifeseitn]].",
'searchsubtitleinvalid' => 'Dei Suachãnfråg: „$1“.',
'noexactmatch'          => "'''Es gibt ka Seitn mi'm Titl „$1“.'''
Wãnn'st di mid dem Thema auskennst, kãnnst [[:$1|de Seitn söiwa schreim]].",
'viewprevnext'          => 'Zoag ($1) ($2) ($3)',
'powersearch'           => 'Suach',

# Preferences page
'mypreferences'         => 'Eistellunga',
'changepassword'        => 'Passwort ändan',
'math_unknown_function' => 'Unbekannte Funktion',
'oldpassword'           => 'Oids Passwort:',
'newpassword'           => 'Neis Passwort:',
'retypenew'             => 'Neis Passwort (no amoi):',
'textboxsize'           => 'Bearbatn',
'searchresultshead'     => 'Suachn',
'guesstimezone'         => 'Vom Browser übanehma',
'allowemail'            => 'E-Mail-Empfang vo andere Benutzer möglich macha.',

# User rights
'userrights-groupsmember' => 'Mitglied vo:',
'userrights-no-interwiki' => 'Du hast koa Berechtigung, Benutzerrechte in anderne Wikis zum ändern.',

# Recent changes
'diff'            => 'Untaschied',
'minoreditletter' => 'K',

# Recent changes linked
'recentchangeslinked' => 'Valinkts prüfn',

# Upload
'upload'            => 'Aufelådn',
'reupload'          => 'Abbrecha',
'uploadnologin'     => 'Net ogmeidt',
'uploadnologintext' => "Sie miassn [[Special:UserLogin|ogmeidt sei]], wenn S' Dateien hoachladn wolln.",
'uploadlog'         => 'Datei-Logbuach',
'uploadlogpage'     => 'Datei-Logbuach',
'uploadedfiles'     => 'Hoachgladene Dateien',
'badfilename'       => "Da Dateinam is in „$1“ g'ändat won.",
'large-file'        => 'De Dateigreß sollat nach Möglichkeit $1 net überschreitn. De Datei is $2 groaß.',
'emptyfile'         => "De hochgladene Datei is laar. Da Grund konn a Tippfehler im Dateinam sei. Bitte kontrollieren'S, ob Sie de Datei wirklich hochladn woin.",
'successfulupload'  => 'Erfolgreich hoachgladn',
'uploadwarning'     => 'Obacht',
'uploaddisabled'    => "'tschuldigung, as Hochladn is deaktiviert.",
'uploadscripted'    => 'De Datei enthalt HTML- oda Scriptcode, der irrtümlichaweis von am Webbrowser ausgführt wern kinnat.',
'watchthisupload'   => 'De Seitn beobachtn',
'filewasdeleted'    => 'A Datei mit dem Nama is scho oamoi hochgladn worn und zwischenzeitlich wieda glöscht worn. Bitte schaug erscht den Eintrag im $1 oo, bevor du de Datei wirklich speicherst.',
'upload-wasdeleted' => "'''Obacht: Du ladst aa Datei hoach, de scho friara glöscht worn is.'''
Bittschee prüf gnau, ob as erneite Hoachladn de Richtlinien entspricht.
Zu deina Information folgt des Lösch-Logbuach mit da Begründung fia de vorherige Löschung:",

# Some likely curl errors. More could be added from <http://curl.haxx.se/libcurl/c/libcurl-errors.html>
'upload-curl-error6' => 'URL is net erreichbar',

'license-nopreview'  => '(es gibt koa Vorschau)',
'upload_source_file' => ' (a Datei auf deim Computa)',

# Image list
'ilsubmit'                  => 'Suach',
'filehist-datetime'         => 'Version vum',
'shareduploadwiki-desc'     => 'Es folgt der Inhalt der $1 aus dem gemeinsam benutzten Repositorium.',
'noimage'                   => "A Datei mit dem Nam existiert net, Sie kinnan s' abe $1.",
'uploadnewversion-linktext' => 'A neie Version vo dera Datei hoachladn',

# File reversion
'filerevert-defaultcomment' => 'zruckgsetzt auf de Version vom $1, $2',
'filerevert-submit'         => 'Zrucksetzen',

# File deletion
'filedelete-legend' => 'Lösch de Datei',
'filedelete-intro'  => "Du löschst de Datei '''„[[Media:$1|$1]]“'''.",

# MIME search
'mimesearch-summary' => 'Auf dieser Spezialseite können die Dateien nach dem MIME-Typ gefiltert werden. Die Eingabe muss immer den Medien- und Subtyp beinhalten: <tt>image/jpeg</tt> (siehe Bildbeschreibungsseite).',
'download'           => 'Runterladn',

# Unused templates
'unusedtemplates' => 'Net benutzte Vorlagen',

# Random page
'randompage' => 'Zuafalls-Artikl',

# Statistics
'statistics-mostpopular' => 'Am meistn bsuachte Seitn',

'disambiguationspage'  => 'Template:Begriffsklärung',
'disambiguations-text' => 'De folgenden Seitn valinkn auf a Seitn zur Begriffsklärung.
Sie solltn stattdessn auf de eigentlich gemoante Seitn valinkn.<br />A Seitn werd ois Begriffsklärungsseitn behandelt, wenn [[MediaWiki:Disambiguationspage]] auf sie valinkt.<br />
Links aus Namensräume wern da net aufglistet.',

'withoutinterwiki-submit' => 'Zoag',

# Miscellaneous special pages
'uncategorizedtemplates' => 'Net kategorisierte Vorlagen',
'allpages'               => 'Alle Seitn',
'longpages'              => 'Lange Seitn',
'specialpages'           => 'Spezial-Seitn',
'newpages'               => 'Neie Seitn',
'ancientpages'           => 'Scho länger nimma bearbate Artikel',
'move'                   => 'vaschiam',
'notargettitle'          => 'Koa Seitn ogem',

# Book sources
'booksources-go' => 'Suach',

# Special:Log
'log'           => 'Logbiacha',
'all-logs-page' => 'Alle Logbiacha',
'alllogstext'   => 'Des is de kombinierte Anzeige vo alle in {{SITENAME}} gführten Logbiacha. Die Ausgabe ko durch de Auswahl vom Logbuchtyp, vom Benutzer oder vom Seitntitel eigschränkt wern.',
'logempty'      => 'Koane passenden Einträg.',

# Special:Allpages
'allpagesfrom'      => 'Seitn zoang ab:',
'allarticles'       => 'Alle Seitn',
'allinnamespace'    => 'Alle Seitn (Namensraum: $1)',
'allnotinnamespace' => 'Alle Seitn (net im $1 Namensraum)',
'allpagesprev'      => 'Vorige',
'allpagesnext'      => 'Nachste',
'allpagessubmit'    => 'Owendn',
'allpagesprefix'    => 'Seitn zoagn mit Präfix:',
'allpagesbadtitle'  => 'Da eigemne Seitennam is net gültig: Er håt entweda an vorogestellts Språch-, a Interwiki-Kürzel oda oa oda mehrere Zeichn, de im Seitnnam net verwendt wern derfan.',
'allpages-bad-ns'   => "Den Namensraum „$1“ gibt's in {{SITENAME}} net.",

# Special:Listusers
'listusers-submit'   => 'Zoag',
'listusers-noresult' => 'Koane Benutzer gfunden.',

# E-mail user
'mailnologin'   => 'Sie san net oogmeidt.',
'emailuser'     => 'E-Mail an den Benutza',
'noemailtitle'  => 'Koa E-Mail-Adress',
'emailfrom'     => 'Vo',
'emailsend'     => 'Sendn',
'emailccme'     => 'Schick a Kopie vo da E-Mail an mi selba',
'emailsenttext' => 'Eana E-Mail is verschickt wrn.',

# Watchlist
'watchlist'         => 'Beobachtungslistn',
'mywatchlist'       => 'Beobachtungslistn',
'watchlistanontext' => 'Sie miaßn si $1, um Eanane Beobachtungslistn zum seng oda Einträge auf ihr zum bearbatn.',
'watchnologin'      => 'Sie san net ogmeidt',
'addedwatch'        => 'Zua Beobachtungslistn dazuado',
'addedwatchtext'    => 'De Seitn „$1“ is zua deina [[Special:Watchlist|Beobachtungslistn]] dazuado worn.
Änderunga an dera Seitn und vo da Diskussionsseitn wern da glistet und
in da Übasicht vo de [[Special:RecentChanges|letztn Änderungen]] in Fettschrift ozoagt. 
Wennst de Seitn wieder vo deina Beobachtungslistn wegdoa mechtn, klickst auf da jeweiligen Seitn auf „nimma beobachten“.',
'watch'             => 'Beobåchtn',
'watchthispage'     => 'Seitn beobachtn',
'unwatch'           => 'nimma beobachten',
'unwatchthispage'   => 'Nimma beobåchtn',
'wlheader-enotif'   => '* Da E-Mail-Benachrichtigungsdienst is aktiviert.',
'watchlistcontains' => 'Dei Beobachtungslistn enthoit $1 {{PLURAL:$1|Seite|Seitn}}.',
'wlshowlast'        => 'Zoag de Änderunga vo de letzten $1 Stunden, $2 Tag oda $3 (in de letzten 30 Tag).',

# Displayed when you click the "watch" button and it's in the process of watching
'watching'   => 'Beobåchtn …',
'unwatching' => 'Net beobachtn …',

'enotif_reset'       => 'Alle Seiten als besuacht markiern',
'enotif_newpagetext' => 'Des is a neie Seitn.',
'changed'            => "g'ändat",
'enotif_lastvisited' => 'Alle Änderungen auf oan Blick: $1',
'enotif_body'        => 'Liaba/e $WATCHINGUSERNAME,
de {{SITENAME}} Seitn "$PAGETITLE" is vo $PAGEEDITOR am $PAGEEDITDATE $CHANGEDORCREATED worn.
Zusammenfassung vom Bearbeiter: $PAGESUMMARY $PAGEMINOREDIT
Es wern solang koae weitern Benachrichtigungsmails gsendt, bis Sie de Seitn wieder besuacht ham. Auf Eanana Beobachtungsseitn kinnans S\' alle Benachrichtigungsmarker zsamm zrucksetzen.
             Eana {{SITENAME}} Benachrichtigungssystem
-- 
Um die Einstellungen Ihrer Beobachtungslistn anzupassen bsuachans bitte: {{fullurl:Special:Watchlist/edit}}',

# Delete/protect/revert
'deletepage'                  => 'Seitn löschen',
'excontent'                   => "Oida Inhalt: '$1'",
'exblank'                     => 'Seitn is laar gwen',
'historywarning'              => 'OBACHT: Die Seitn, de Sie löschen wolln, håt a Versionsgeschichte:',
'confirmdeletetext'           => 'Sie san dabei, a Seitn oda a Datei und alle zughörigen ältern Versionen
zum löschen. Bitte bestätigen Sie da dazu, dass Sie de Konsequenzen verstengan
und dass Sie in Übaeinstimmung mit de [[{{MediaWiki:Policy-url}}|Richtlinien]] handeln.',
'deletedtext'                 => '„$1“ is glöscht worn. Im $2 findn Sie a Listn vo de letzten Löschungen.',
'deletedarticle'              => 'håd „[[$1]]“ glöscht',
'dellogpage'                  => 'Lösch-Logbuach',
'deletionlog'                 => 'Lösch-Logbuach',
'reverted'                    => 'Auf a oide Version zruckgesetzt',
'deletecomment'               => 'Grund vo dera Löschung',
'rollbacklink'                => 'Zrucksetzen',
'protectlogpage'              => 'Seitenschutz-Logbuach',
'protect-level-autoconfirmed' => 'Sperrung fia net registrierte Benutzer',

# Restrictions (nouns)
'restriction-move' => 'verschiam',

# Undelete
'undelete'               => 'Glöschte Seitn wiedaherstelln',
'undeletehistorynoadmin' => 'De Seitn is glöscht worn. Da Grund fia de Löschung is in da Zsammafassung oogem,
genau wia Details zum letztn Benutza der de Seitn vor da Löschung bearbat håt.
Da aktuelle Text vo da glöschtn Seitn is nur fia Administratoren zum seng.',
'undeletebtn'            => 'Wiedaherstelln',
'undeletelink'           => 'wiederherstellen',
'undeletereset'          => 'Abbrecha',
'undeletedarticle'       => 'håt „[[$1]]“ wieda hergstellt',
'undeletedfiles'         => '$1 {{plural:$1|Datei|Dateien}} san wieda hergstellt worn',
'undelete-search-box'    => 'Suach nach glöschte Seitn',
'undelete-search-submit' => 'Suach',

# Namespace form on various pages
'namespace'      => 'Nãmensraum:',
'blanknamespace' => '(Seitn)',

# Contributions
'contributions' => 'Benutzerbeiträg',
'mycontris'     => 'Eigene Beiträg',
'contribsub2'   => 'Fia $1 ($2)',

'sp-contributions-newbies-sub' => 'Fia Neiling',
'sp-contributions-search'      => 'Suach nach Benutzerbeiträge',

# What links here
'whatlinkshere' => 'Links auf de Seitn',
'isredirect'    => 'Weiterleitungsseitn',

# Block/unblock
'blockip'            => 'IP-Adresse/Benutzer sperrn',
'badipaddress'       => 'De IP-Adress håt a falsch Format.',
'blockipsuccesssub'  => 'De Sperre war erfoigreich',
'ipb-unblock-addr'   => '„$1“ freigem',
'ipb-unblock'        => 'IP-Adresse/Benutzer freigem',
'unblockip'          => 'IP-Adresse freigem',
'ipusubmit'          => 'Freigem',
'unblocked'          => '[[User:$1|$1]] is freigem worn',
'createaccountblock' => 'Erstellung vo Benutzakonten gsperrt',
'blocklink'          => 'sperrn',
'unblocklink'        => 'freigem',
'contribslink'       => 'Beiträge',
'autoblocker'        => "Automatische Sperre, weil s' a gmeinsame IP-Adressn mit „$1“ hernehma. Grund: „$2“.",

# Developer tools
'unlockdb'            => 'Datenbank freigem',
'unlockconfirm'       => 'Ja, i mecht de Datenbank freigem.',
'unlockbtn'           => 'Datenbank freigem',
'locknoconfirm'       => 'Sie ham des Bestätigungsfeld net markiert.',
'lockfilenotwritable' => "Die Datenbank-Sperrdatei ist net beschreibbar. Zum Sperrn oda Freigem vo da Datenbank muaß de für'n Webserver beschreibbar sei.",
'databasenotlocked'   => 'De Datenbank is net gsperrt.',

# Move page
'movepage'               => 'Seitn vaschiam',
'move-watch'             => 'De Seitn beobachten',
'movepagebtn'            => 'Seitn vaschiam',
'articleexists'          => 'Unter dem Nam existiert bereits a Seitn.
Bitte nehmans an andern Nam.',
'1movedto2'              => 'håt [[$1]] nåch [[$2]] verschom',
'1movedto2_redir'        => 'håt [[$1]] nåch [[$2]] verschom und dabei a Weiterleitung überschriem',
'revertmove'             => 'zruck vaschiam',
'delete_and_move'        => 'Löschn und vaschiam',
'delete_and_move_reason' => 'glöscht, um Plåtz fia Vaschiam zum macha',
'selfmove'               => 'Ursprungs- und Zielname sand gleich; a Seitn kann net auf sich selber verschom wern.',

# Namespace 8 related
'allmessagesname'           => 'Nam',
'allmessagescurrent'        => 'Aktuella Text',
'allmessagestext'           => 'Des is a Listn vo de MediaWiki-Systemtexte.
Please visit [http://www.mediawiki.org/wiki/Localisation MediaWiki Localisation] and [http://translatewiki.net translatewiki.net] if you wish to contribute to the generic MediaWiki localisation.',
'allmessagesnotsupportedDB' => "'''Special:Allmessages''' is im Moment net möglich, wei de Datenbank offline is.",
'allmessagesmodified'       => 'Nur geänderte zoagn',

# Special:Import
'importnotext' => 'Laar oder koa Text',

# Import log
'importlogpage' => 'Import-Logbuach',

# Tooltip help for the actions
'tooltip-pt-preferences'          => 'Eigene Eistellunga',
'tooltip-pt-mycontris'            => 'Liste vo eigene Beiträg',
'tooltip-pt-logout'               => 'Obmeidn',
'tooltip-ca-addsection'           => 'An Kommentar zua dera Diskussion dazuagem.',
'tooltip-ca-viewsource'           => 'De Seitn is gschützt. An Quelltext kann ma oschaun.',
'tooltip-ca-history'              => 'Friarane Versionen vo dera Seitn',
'tooltip-ca-protect'              => 'De Seitn schützen',
'tooltip-ca-delete'               => 'De Seitn löschen',
'tooltip-ca-move'                 => 'De Seitn vaschiam',
'tooltip-ca-watch'                => 'De Seitn zua persönlichen Beobachtungslistn dazua doa',
'tooltip-ca-unwatch'              => 'De Seitn von da persönlichen Beobachtungslistn entferna',
'tooltip-search'                  => '{{SITENAME}} durchsuacha',
'tooltip-p-logo'                  => 'Hauptseitn',
'tooltip-n-mainpage'              => "d'Hauptseitn ãnzoang",
'tooltip-n-randompage'            => 'Zufällige Seitn',
'tooltip-t-upload'                => 'Datein aufelådn',
'tooltip-ca-nstab-main'           => 'Seitninhalt ozoagn',
'tooltip-ca-nstab-help'           => 'Huifseitn oozoang',
'tooltip-save'                    => 'Änderunga speichan',
'tooltip-compareselectedversions' => 'Unterschiede zwischn zwoa ausgewählte Versiona vo dera  Seitn vergleicha.',
'tooltip-watch'                   => 'De Seitn da persönlichn Beobachtungslistn dazua doa.',
'tooltip-recreate'                => 'Seitn nei erstelln, obwoi sie glöscht worn is.',

# Attribution
'lastmodifiedatby' => 'De Seitn is zletzt am $1 um $2 vo $3 gändert worn.', # $1 date, $2 time, $3 user
'othercontribs'    => 'Basiert auf da Arbat vo $1',
'creditspage'      => 'Seitninformationa',

# Patrolling
'markedaspatrollederrortext' => 'Sie miaßn a Seitnänderung auswähln.',

# Image deletion
'deletedrevision'    => 'Oide Version $1 glöscht.',
'filedelete-missing' => 'De Datei „$1“ ko net glöscht wern, weils es net gibt.',

# Browsing diffs
'previousdiff' => '← Zum vorigen Versionsunterschied',

# Special:Newimages
'newimages' => 'Neie Dateien',
'noimages'  => 'Koane Datein gfunden.',

# EXIF tags
'exif-gpsspeed' => 'Geschwindigkeit vom GPS-Empfänger',

'exif-componentsconfiguration-0' => "Gibt's net",

# 'all' in various places, this might be different for inflected languages
'namespacesall' => 'ålle',

# E-mail address confirmation
'confirmemail_send'      => 'Bestätigungscode zuaschicka',
'confirmemail_needlogin' => 'Sie miassn si $1 um Eana E-Mail-Adress zum bestätigen.',

# Multipage image navigation
'imgmultipageprev' => '← vorige Seitn',
'imgmultipagenext' => 'nächste Seitn →',

# Table pager
'table_pager_next'  => 'Nächste Seitn',
'table_pager_first' => 'Erste Seitn',
'table_pager_last'  => 'Letzte Seitn',
'table_pager_empty' => 'Koane Ergebnisse',

# Auto-summaries
'autosumm-blank'   => 'De Seitn is gleert worn.',
'autosumm-replace' => "Da Seitninhalt is durch an andern Text ersetzt worn: '$1'",
'autoredircomment' => 'Weiterleitung nåch [[$1]] is erstellt worn',
'autosumm-new'     => 'De Seitn is nei oglegt worn: $1',

# Size units
'size-bytes' => '$1 Bytes',

# Watchlist editor
'watchlistedit-noitems'        => 'Dei Beobachtungslistn is laar.',
'watchlistedit-normal-title'   => 'Beobachtungslistn bearbatn',
'watchlistedit-normal-legend'  => 'Eiträge vo da Beobachtungslistn wegnehma',
'watchlistedit-normal-explain' => 'Des sand de Eiträge vo deiner Beobachtungslistn. Um Eiträge zum entferna, markier de Kastl nem de Eiträg und klick auf „Eiträg entferna“. Du kannst dei Beobachtungsliste aa im [[Special:Watchlist/raw|Listenformat bearbatn]].',
'watchlistedit-normal-submit'  => 'Eiträge wegnehma',
'watchlistedit-raw-titles'     => 'Eiträg:',

# Special:Version
'version-hook-subscribedby' => 'Aufruf vo',

);
