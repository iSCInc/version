<?php
/** Sichuan Yi (ꆇꉙ)
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'zh-cn';

