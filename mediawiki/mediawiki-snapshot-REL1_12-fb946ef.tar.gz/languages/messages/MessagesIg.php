<?php
/** Igbo (Igbo)
 *
 * @ingroup Language
 * @file
 *
 */

$messages = array(
'navigation' => 'evu vo',

'search'         => 'Chozie ihe i dị cho',
'toolbox'        => 'Ngwa Oru',
'otherlanguages' => "Edemede nke n'olu ndị ọzọ",

# All link text and link target definitions of links into project namespace that get used by other message strings, with the exception of user group pages (see grouppage) and the disambiguation template definition (see disambiguations).
'mainpage'        => 'Page mbu',
'portal'          => 'Lounge',
'portal-url'      => 'Project:Lounge',
'sitesupport-url' => 'Project:Enemaka ego',

'youhavenewmessagesmulti' => 'Inwere eziohu na $1',

# Short words for each namespace, by default used in the namespace tab in monobook
'nstab-template' => 'Model',

# What links here
'whatlinkshere' => 'Ihe na bia nga',

);
