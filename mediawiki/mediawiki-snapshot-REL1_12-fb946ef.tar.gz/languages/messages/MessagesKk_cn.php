<?php
/** Kazakh (China) (‫قازاقشا (جۇنگو)‬)
 *
 * @ingroup Language
 * @file
 *
 */

# Inherit everything for now
$fallback = 'kk-arab';

