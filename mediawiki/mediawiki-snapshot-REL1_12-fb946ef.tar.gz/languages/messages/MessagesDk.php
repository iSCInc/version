<?php
/** Danish (Dansk)
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'da';

