<?php

global $wgAllMessagesUdm;
$wgAllMessagesUdm = array(
'linkprefix' => '/^(.*?)(„|«)$/sDu',
'article' => 'Статья',
'createaccount' => 'выль вики-авторлэн регистрациез',
'edit' => 'тупатыны',
'hist' => 'история',
'history' => 'Бамлэн историез',
'history_short' => 'история',
'login' => 'Википедие пырон',
'mycontris' => 'мынам статьяосы',
'mytalk' => 'викиавтор сярысь вераськон',
'nstab-user' => 'викиавтор',
'preferences' => 'настройкаос',
);

?>