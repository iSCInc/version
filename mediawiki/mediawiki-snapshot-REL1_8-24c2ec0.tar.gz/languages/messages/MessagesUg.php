<?php
/** Uyghur (Oyghurque)
  *
  * @package MediaWiki
  * @subpackage Language
  */

$rtl = true;

?>
