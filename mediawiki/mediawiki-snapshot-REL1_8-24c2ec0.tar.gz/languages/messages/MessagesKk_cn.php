<?php
/** Kazakh Arabic (قازاق)
  *
  * @package MediaWiki
  * @subpackage Language
  */

$rtl = true;

?>
