<?php

/** Aramaic ( ܕܥܒܪܸܝܛ )
  *
  * @package MediaWiki
  * @subpackage Language
  */

$rtl = true;
$defaultUserOptionOverrides = array(
	# Swap sidebar to right side by default
	'quickbar' => 2,
);

?>
