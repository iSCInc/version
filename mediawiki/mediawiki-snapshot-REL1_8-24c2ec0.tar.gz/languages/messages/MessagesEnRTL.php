<?php

$rtl = true;

?>
