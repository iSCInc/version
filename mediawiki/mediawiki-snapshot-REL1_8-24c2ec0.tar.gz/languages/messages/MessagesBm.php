<?php
/** Bambara (Bamanankan)
  *
  * @package MediaWiki
  * @subpackage Language
  */

$fallback = 'fr';
?>
