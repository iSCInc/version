<?php
/** Kazakh (Қазақша)
  *
  * @package MediaWiki
  * @subpackage Language
  */

$linkTrail = '/^([a-zа-яäçéğıïñöşüʺʹёәіңғүұқөһ“»]+)(.*)$/sDu';

?>
