<?php
/**
 * Bishnupriya
 * most speakers have Bengali as second language, use as default fallback
 *
 * @package MediaWiki
 * @subpackage Language
 */

$fallback = 'bn';
?>
