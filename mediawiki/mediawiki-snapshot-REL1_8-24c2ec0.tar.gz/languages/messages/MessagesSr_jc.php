<?php
/**
  * @package MediaWiki
  * @subpackage Language
  */

# Inherit everything for now
$fallback = 'sr-ec';

?>
