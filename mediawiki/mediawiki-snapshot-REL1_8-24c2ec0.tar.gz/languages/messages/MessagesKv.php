<?php
/** Komi (Коми)
  *
  * @package MediaWiki
  * @subpackage Language
  */

$fallback = 'ru';
?>
