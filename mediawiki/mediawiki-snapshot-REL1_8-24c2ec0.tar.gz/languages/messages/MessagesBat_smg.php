<?php
/** Samogitian (Žemaitėška)
  *
  * @package MediaWiki
  * @subpackage Language
  */

$fallback = 'lt';
?>
