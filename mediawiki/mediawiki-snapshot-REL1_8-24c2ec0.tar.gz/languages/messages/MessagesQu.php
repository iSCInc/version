<?php
/** Quechua (Runa Simi)
  *
  * @package MediaWiki
  * @subpackage Language
  */

$fallback = 'es';
?>
