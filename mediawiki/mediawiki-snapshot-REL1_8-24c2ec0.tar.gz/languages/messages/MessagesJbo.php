<?php
/** Lojban (Lojban)
  *
  * @package MediaWiki
  * @subpackage Language
  */

$messages = array(

'1movedto2'		=> 'le pu se cmene lu [[$1]] li\'u cu ca se cmene lu [[$2]] li\'u',
'categories'		=> '{{PLURAL:$1|klesi|klesi}}',
'currentevents'		=> 'nuzba ckupau',
'currentevents-url'	=> 'nuzba ckupau',
'help'			=> 'sidju ckupau',
'mainpage'		=> 'ralju ckupau',
'movedto'		=> 'te muvdu',
'pagemovedtext'		=> '[[$1]] te muvdu [[$2]] le vreji',
'portal'		=> 'bende ckupau',
'randompage'		=> 'cunso ckupau'

);

?>
