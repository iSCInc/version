<?

/* This file is obsolete... 2003-08-21 */

?>
