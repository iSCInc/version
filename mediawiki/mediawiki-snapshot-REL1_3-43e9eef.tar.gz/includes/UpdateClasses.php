<?php
# See deferred.doc
require_once( "UserUpdate.php" );
require_once( "ViewCountUpdate.php" );
require_once( "SiteStatsUpdate.php" );
require_once( "LinksUpdate.php" );
require_once( "SearchUpdate.php" );
require_once( "UserTalkUpdate.php" );
require_once( "SquidUpdate.php" );

?>
