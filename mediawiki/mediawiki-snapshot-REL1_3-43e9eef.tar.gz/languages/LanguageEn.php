<?php
# See language.doc

class LanguageEn extends Language {
	# Inherit everything
}

?>
