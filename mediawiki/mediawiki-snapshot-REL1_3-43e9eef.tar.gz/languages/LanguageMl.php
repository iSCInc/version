<?php
# See language.doc

require_once( "LanguageUtf8.php" );

class LanguageMl extends LanguageUtf8 {
	# Inherit everything

}
?>
