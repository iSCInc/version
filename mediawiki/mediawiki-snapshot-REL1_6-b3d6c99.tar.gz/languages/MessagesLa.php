<?php


$wgAllMessagesLa = array(

# User Toggles

"tog-underline" => "Subscribere nexi",
"tog-highlightbroken" => "Formare nexos fractos <a href=\"\" class=\"new\">sici</a> (alioqui: sic<a href=\"\" class=\"internal\">?</a>).",
"tog-justify"	=> "Saepire capites",
"tog-hideminor" => "Celare mutationes recentes minores",
"tog-usenewrc" => "Mutationes recentes amplificatae (non efficit in tota navigatra)",
"tog-numberheadings" => "Numerare indices necessario",
"tog-rememberpassword" => "Recordari tesserae inter conventa (uti cookies)",
"tog-editwidth" => "Capsa recensitorum totam latitudinem habet",
"tog-editondblclick" => "Premere bis ut paginam recensere (uti JavaScript)",
"tog-watchdefault" => "Custodire res novas et mutatas",
"tog-minordefault" => "Notare totas mutations ut minor",
"tog-previewontop" => "Monstrare praevisus ante capsam recensiti, non post ipsam",

# Dates

'sunday' => 'dies Solis',
'monday' => 'dies Lunae',
'tuesday' => 'dies Martis',
'wednesday' => 'dies Mercuri',
'thursday' => 'dies Iovis',
'friday' => 'dies Veneris',
'saturday' => 'dies Saturni',
'january' => 'Ianuarii',
'february' => 'Februarii',
'march' => 'Martii',
'april' => 'Aprilis',
'may_long' => 'Maii',
'june' => 'Iunii',
'july' => 'Iulii',
'august' => 'Augusti',
'september' => 'Septembri',
'october' => 'Octobri',
'november' => 'Novembri',
'december' => 'Decembri',
'jan' => 'ian',
'feb' => 'feb',
'mar' => 'mar',
'apr' => 'apr',
'may' => 'mai',
'jun' => 'iun',
'jul' => 'iul',
'aug' => 'aug',
'sep' => 'sep',
'oct' => 'oct',
'nov' => 'nov',
'dec' => 'dec',

# Math
'mw_math_png' => "Semper vertere PNG",
'mw_math_simple' => "HTML si admodum simplex, alioqui PNG",
'mw_math_html' => "HTML si fieri potest, alioqui PNG",
'mw_math_source' => "Stet ut TeX (pro navigatri texti)",
'mw_math_modern' => "Commendatum pro navigatri recentes",
'mw_math_mathml' => 'MathML',
);


?>