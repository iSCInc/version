<?php
/** English (English)
  *
  * @package MediaWiki
  * @subpackage Language
  */

/** */
require_once( 'LanguageUtf8.php' );

/** @package MediaWiki */
class LanguageEn extends LanguageUtf8 {
	# Inherit everything
}

?>
