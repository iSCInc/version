<?php

/* private */ $wgAllMessagesVec = array(

# no messages yet

);

?>