<?php
/** Uyghur (Oyghurque)
  *
  * @addtogroup Language
  */

$rtl = true;

?>
