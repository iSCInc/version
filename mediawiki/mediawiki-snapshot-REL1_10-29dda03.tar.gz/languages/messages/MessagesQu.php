<?php
/** Quechua (Runa Simi)
  *
  * @addtogroup Language
  */

$fallback = 'es';
?>
