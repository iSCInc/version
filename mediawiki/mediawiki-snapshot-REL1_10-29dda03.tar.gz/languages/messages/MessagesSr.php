<?php
/**
  * Serbian
  *
  * @addtogroup Language
  */

$fallback = 'sr-ec';
$linkTrail = '/^([abvgdđežzijklljmnnjoprstćufhcčdžšабвгдђежзијклљмнњопрстћуфхцчџш]+)(.*)$/usD';

?>
