<?php
/** Zhuang (壮语)
  *
  * @addtogroup Language
  */

$fallback = 'zh-cn';
?>
