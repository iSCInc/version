<?php
/** Samogitian (Žemaitėška)
  *
  * @addtogroup Language
  */

$fallback = 'lt';
?>
