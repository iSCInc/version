<?php

$fallback = 'ru';

?>
