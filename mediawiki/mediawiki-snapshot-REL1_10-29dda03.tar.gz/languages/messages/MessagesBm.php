<?php
/** Bambara (Bamanankan)
  *
  * @addtogroup Language
  */

$fallback = 'fr';
?>
