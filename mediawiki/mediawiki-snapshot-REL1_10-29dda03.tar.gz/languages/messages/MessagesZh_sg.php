<?php

/**
  * @addtogroup Language
  */
# Inherit everything for now
$fallback = 'zh-cn';

?>
