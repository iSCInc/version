<?php
/**
 * Bavarian (Boarisch)
 *
 * @addtogroup Language
 */

$fallback = 'de';

$messages = array(

'mainpage'	=> 'Hauptsaitn',

);

?>
