<?php
/** Chechen (Нохчийн)
  *
  * @addtogroup Language
  */

$fallback = 'ru';
?>
