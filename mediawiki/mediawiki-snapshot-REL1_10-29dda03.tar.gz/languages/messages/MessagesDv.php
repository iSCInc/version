<?php
/** Dhivehi language file ( ދިވެހިބަސް',      )
  *
  * @addtogroup Language
  */

$rtl = true;
?>
