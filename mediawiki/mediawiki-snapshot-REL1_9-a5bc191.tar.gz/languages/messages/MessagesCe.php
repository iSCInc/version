<?php
/** Chechen (Нохчийн)
  *
  * @package MediaWiki
  * @subpackage Language
  */

$fallback = 'ru';
?>
