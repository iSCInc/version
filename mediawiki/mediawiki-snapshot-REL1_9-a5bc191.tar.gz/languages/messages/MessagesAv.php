<?php
/** Avar (Авар)
  *
  * @package MediaWiki
  * @subpackage Language
  */

$fallback = 'ru';
?>