<?php
# See deferred.doc
include_once( "UserUpdate.php" );
include_once( "ViewCountUpdate.php" );
include_once( "SiteStatsUpdate.php" );
include_once( "LinksUpdate.php" );
include_once( "SearchUpdate.php" );
include_once( "UserTalkUpdate.php" );
include_once( "SquidUpdate.php" );

?>
