<?php

include_once( "LanguageMs.php" );

class LanguageId extends LanguageMs {
	/* Inherit everything. */
}

?>