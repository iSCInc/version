<?

/* 
 *	@package Mediawiki
 *
 *	This class should provide methods for message 
 *	cache key hints for various scopes */

class MessageCacheHints {
	function get($scope="global") {
		return array('TODO');
	}
}

?>
