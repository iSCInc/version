<?
/**
 * This file is obsolete... 2003-08-21
 * @deprecated
 * @package MediaWiki
 */
?>
