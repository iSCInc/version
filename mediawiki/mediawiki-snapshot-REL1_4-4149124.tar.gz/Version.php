<?php
# The actual version number is in DefaultSettings.php
# and can be seen through the wiki at [[Special:Version]]

# This is for an ancient update item and probably is not
# necessary.
$wgSoftwareRevision = 1002;
?>
