<?php
/** English (English)
  *
  * @package MediaWiki
  * @subpackage Language
  */

require_once( 'LanguageUtf8.php' );

class LanguageEn extends LanguageUtf8 {
	# Inherit everything
}

?>
