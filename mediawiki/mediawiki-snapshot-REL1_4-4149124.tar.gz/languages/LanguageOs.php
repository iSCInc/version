<?php
# Ossetic stub localization; default to Russian instead of English.
# See language.doc

require_once( "LanguageRu.php" );

class LanguageOs extends LanguageRu {
	# Inherit everything

}
?>
