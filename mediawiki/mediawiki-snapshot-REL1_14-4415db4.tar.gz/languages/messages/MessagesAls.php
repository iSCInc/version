<?php
/** Alemannisch
 *
 * @ingroup Language
 * @file
 * @comment Deprecated code. Falls back to 'gsw'.
 */

$fallback = 'gsw';
