<?php
/** Sindhi language file ( सिनधि )
  *
  * @package MediaWiki
  * @subpackage Language
  */

require_once( 'LanguageUtf8.php' );

class LanguageSd extends LanguageUtf8 {
	#FIXME: inherit almost everything for now

	function isRTL() {
		return true;
	}
}

?>
