<?php
/**
 * See deferred.txt
 *
 * @package MediaWiki
 */

/**
 *
 */

require_once( 'SiteStatsUpdate.php' );
require_once( 'LinksUpdate.php' );
require_once( 'SearchUpdate.php' );
require_once( 'SquidUpdate.php' );

?>